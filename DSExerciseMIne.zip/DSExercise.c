#include"stdio.h"
#include"stdlib.h"

int main(int argc, char *argv[])
{
    printf("Hello DS\n");
    system("pause");
    return 0;
}